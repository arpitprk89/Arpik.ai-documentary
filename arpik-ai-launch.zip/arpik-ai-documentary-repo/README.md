# ARPIK.AI: Beyond the Crowd

A bilingual (English and Hindi) storytelling documentary about why ARPIK.AI was built.

**Watch:** https://arpitprk89.github.io/Arpik.ai-documentary/
**App:** https://arpik-ai.vercel.app/

Single self-contained `index.html`. No build step. Host it with GitHub Pages (Settings, Pages, branch `main`, folder `/ (root)`).
To change the final button link, edit the `U` value in the script.

Created by Arpit Pareek.
